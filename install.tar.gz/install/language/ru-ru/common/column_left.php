<?php
$_['text_license']           = 'Лицензия';
$_['text_installation']      = 'Проверка';
$_['text_configuration']     = 'Настройка';
$_['text_finished']          = 'Завершение';
$_['text_upgrade']       = 'Обновление';
$_['text_language']      = 'Язык интерфейса';