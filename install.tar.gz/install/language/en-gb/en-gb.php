<?php
// Button
$_['button_continue'] = 'Continue';
$_['button_back']     = 'Back';

// Error
$_['error_exception'] = 'Error Code(%s): %s in %s on line %s';